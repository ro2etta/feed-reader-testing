# Project Overview

In this project you are given a web-based application that reads RSS feeds. The original developer of this application clearly saw the value in testing, they've already included [Jasmine](http://jasmine.github.io/) and even started writing their first test suite! Unfortunately, they decided to move on to start their own company and we're now left with an application with an incomplete test suite. That's where you come in.

#What did I do to make it work ?
- as for the given RSS feed defined , every time we call the expect , it will show that its defined already.
- I have used the for loop to make sure that all of the URL's inside the website are defined correctly with a length > than 0 and String value .
- I have used the for loop to make sure that all of the names inside the website are defined correctly with a length > than 0 and in a String value .
- as for the menu , I have used two expect along with the jquery to check the hidden feature of the menu , and what it would do on click .
- as for the Initial Entries , this one requires asynchronous activity , so I called the beforeEach function along with loadFeed using its variable to check .
- as for the New feed selection , to check the load of different feeds , I have used two variables and used the jquery to test it .

#How it will work ?
load the page and check the Jasmine along , make sure that all expect are working correctly , smoothly with no errors appearing.
